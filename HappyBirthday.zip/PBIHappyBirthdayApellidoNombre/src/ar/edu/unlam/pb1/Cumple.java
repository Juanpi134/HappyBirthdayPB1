package ar.edu.unlam.pb1;

import java.util.Arrays;

public class Cumple {

	/***
	 * Se deben agregar todos los atributos que se requieran.
	 */
	
	/****
	 * El constructor debe realizar todas las acciones necesarias para garantizar el correcto funcionamiento
	 * @param cuantosCumple Esto es un valor num�rico que identifica los a�os que se celebran en el presente cumplea�os
	 * @param tematica Esto es una variable de tipo String que denota la tem�tica del cumplea�os. 
	 */
	public Cumple(int cuantosCumple, String tematica) {
	}
	
	/***
	 * Agrega un nuevo invitado a la lista de invitados del cumplea�os
	 * @param nuevo - El invitado a agregar
	 * @return Devuelve true si se pudo agregar al nuevo invitado o false en caso contrario.
	 */
	public boolean agregarInvitado(Invitado nuevo) {

		return false;
	}

	/***
	 * Este m�todo busca un invitado en la lista de invitados a partir de su nombre.
	 * @param nombre Nombre del invitado a buscar.
	 * @return Devuelve true si encuentra al invitado o false en caso contrario.
	 */
	public Invitado buscar(String nombre) {
		return null;
	}

	/****
	 * El m�todo toString debe devolver informaci�n que nos ayude a conocer el estado del objeto Cumple.
	 */
	@Override
	public String toString() {
		return "";
	}
	
	
}
